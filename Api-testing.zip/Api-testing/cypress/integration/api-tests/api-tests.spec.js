describe('QA task api testing', () => {


   it('fetches list of users - GET', () => {
       cy.request('api/users?page=2').as('userRequest');
       cy.get('@userRequest').then(response => {
         cy.fixture('get-users').then((data)=>{
           expect(response.status).to.eq(200);
           expect(response.body.page).to.eq(data.page);
            expect(response.body.per_page).to.eq(data.per_page);
            expect(response.body.total).to.eq(data.total);
            expect(response.body.total_pages).to.eq(data.total_pages);

         });
       });
   });

   it('fetches single users - GET', () => {
       cy.request('api/users/2').as('userRequest');
       cy.get('@userRequest').then(response => {
         cy.fixture('single-user').then((expectedData)=>{
           expect(response.status).to.eq(200);
           expect(response.body.data.id).to.eq(expectedData.data.id);
            expect(response.body.data.email).to.eq(expectedData.data.email);
            expect(response.body.data.first_name).to.eq(expectedData.data.first_name);
            expect(response.body.data.last_name).to.eq(expectedData.data.last_name);

         });
       });
   });

   it('fetches invalid users - GET', () => {
       cy.request({url:'api/users/23',failOnStatusCode: false}).as('userRequest');
       cy.get('@userRequest').then(response => {
           expect(response.status).to.eq(404);
       });
   });

   it('fetches list of resources - GET', () => {
       cy.request('api/unknown').as('userRequest');
       cy.get('@userRequest').then(response => {
         cy.fixture('resource-list').then((expectedData)=>{
           expect(response.status).to.eq(200);
           for (let i = 0; i < response.body.data.length; i++) {
               expect(response.body.data[i].id).to.eq(expectedData.data[i].id)
               expect(response.body.data[i].name).to.eq(expectedData.data[i].name)
               expect(response.body.data[i].year).to.eq(expectedData.data[i].year)
               expect(response.body.data[i].color).to.eq(expectedData.data[i].color)
           }
            expect(response.body.data.page).to.eq(expectedData.data.page);
            expect(response.body.data.per_page).to.eq(expectedData.data.per_page);
            expect(response.body.data.total_pages).to.eq(expectedData.data.total_pages);
         });
       });
   });

   it('fetches single resource - GET', () => {
       cy.request('api/unknown/2').as('userRequest');
       cy.get('@userRequest').then(response => {
         cy.fixture('single-resource').then((expectedData)=>{
           expect(response.status).to.eq(200);
               expect(response.body.data.id).to.eq(expectedData.data.id)
               expect(response.body.data.name).to.eq(expectedData.data.name)
               expect(response.body.data.year).to.eq(expectedData.data.year)
               expect(response.body.data.color).to.eq(expectedData.data.color)
         });
       });
   });

   it('fetches invalid resource - GET', () => {
       cy.request({url:'api/unknown/23',failOnStatusCode: false}).as('userRequest');
       cy.get('@userRequest').then(response => {
           expect(response.status).to.eq(404);
       });
   });

   it('create a user - POST', () => {

         cy.fixture('post-user').then((expectedData)=>{
           cy.request('POST','api/users',expectedData).as('userRequest');
           cy.get('@userRequest').then(response => {
               expect(response.status).to.eq(201);
               expect(response.body.name).to.eq(expectedData.name)
               expect(response.body.job).to.eq(expectedData.job)
         });
       });
   });

   it('Update a user - PUT', () => {

         cy.fixture('put-user').then((expectedData)=>{
           cy.request('PUT','api/users/2',expectedData).as('userRequest');
           cy.get('@userRequest').then(response => {
               expect(response.status).to.eq(200);
               expect(response.body.name).to.eq(expectedData.name)
               expect(response.body.job).to.eq(expectedData.job)
         });
       });
   });

   it('Update a user - PATCH', () => {

         cy.fixture('put-user').then((expectedData)=>{
           cy.request('PATCH','api/users/2',expectedData).as('userRequest');
           cy.get('@userRequest').then(response => {
               expect(response.status).to.eq(200);
               expect(response.body.name).to.eq(expectedData.name)
               expect(response.body.job).to.eq(expectedData.job)
         });
       });
   });

   it('Update a user - PATCH', () => {

         cy.fixture('put-user').then((expectedData)=>{
           cy.request('PATCH','api/users/2',expectedData).as('userRequest');
           cy.get('@userRequest').then(response => {
               expect(response.status).to.eq(200);
               expect(response.body.name).to.eq(expectedData.name)
               expect(response.body.job).to.eq(expectedData.job)
         });
       });
   });

   it('Delete a user - DELETE', () => {

         cy.fixture('put-user').then((expectedData)=>{
           cy.request('DELETE','api/users/2',expectedData).as('userRequest');
           cy.get('@userRequest').then(response => {
               expect(response.status).to.eq(204);

         });
       });
   });

   it('Register a user - POST', () => {
       cy.request('POST','api/register',{
         "email": "eve.holt@reqres.in",
         "password": "pistol"
       }).as('userRequest');
       cy.get('@userRequest').then(response => {

           expect(response.status).to.eq(200);
           expect(response.body).to.have.property('id')
           expect(response.body).to.have.property('token')

       });
   });

   it('unsuccessful register - POST', () => {
       cy.request({method:'POST',url:'api/register',
       body:{"email": "sydney@fife"},failOnStatusCode: false}).as('userRequest');
       cy.get('@userRequest').then(response => {
           expect(response.status).to.eq(400);
           expect(response.body).to.have.property('error','Missing password')
       });
   });

   it('successful login - POST', () => {
       cy.request('POST','api/login',{
    "email": "eve.holt@reqres.in",
    "password": "cityslicka"
    }).as('userRequest');
       cy.get('@userRequest').then(response => {

           expect(response.status).to.eq(200);
           expect(response.body).to.have.property('token')

       });
   });

   it('unsuccessful login - POST', () => {
       cy.request({method:'POST',url:'api/login',
       body:{"email": "sydney@fife"},failOnStatusCode: false}).as('userRequest');
       cy.get('@userRequest').then(response => {
           expect(response.status).to.eq(400);
           expect(response.body).to.have.property('error','Missing password')
       });
   });



   it('Delayed response - GET', () => {
       cy.request('/api/users?delay=3').as('userRequest');
       cy.get('@userRequest').then(response => {
         cy.fixture('delayed-response').then((data)=>{
           expect(response.status).to.eq(200);
           expect(response.body.page).to.eq(data.page);
           expect(response.body.per_page).to.eq(data.per_page);
           expect(response.body.total).to.eq(data.total);
           expect(response.body.total_pages).to.eq(data.total_pages);
         });
       });
   });

});
