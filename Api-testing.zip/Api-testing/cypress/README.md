# QA TASK

In this QA task, I have gone with non gherkin approach for the API TESTING. I have tried to cover all the scenarios in the resreq.in site.
