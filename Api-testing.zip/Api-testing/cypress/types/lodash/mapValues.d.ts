import { mapValues } from "./index";
export = mapValues;
