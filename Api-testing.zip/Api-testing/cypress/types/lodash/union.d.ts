import { union } from "./index";
export = union;
