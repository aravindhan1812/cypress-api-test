import { assignInWith } from "./index";
export = assignInWith;
