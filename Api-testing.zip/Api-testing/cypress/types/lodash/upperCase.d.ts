import { upperCase } from "./index";
export = upperCase;
