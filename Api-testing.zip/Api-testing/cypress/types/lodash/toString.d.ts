import { toString } from "./index";
export = toString;
