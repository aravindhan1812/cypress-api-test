import { isBoolean } from "./index";
export = isBoolean;
