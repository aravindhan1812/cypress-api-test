import { isNaN } from "./index";
export = isNaN;
