import { each } from "./index";
export = each;
