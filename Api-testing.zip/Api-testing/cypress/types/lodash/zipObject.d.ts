import { zipObject } from "./index";
export = zipObject;
