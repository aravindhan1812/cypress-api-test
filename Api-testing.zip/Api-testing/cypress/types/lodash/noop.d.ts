import { noop } from "./index";
export = noop;
