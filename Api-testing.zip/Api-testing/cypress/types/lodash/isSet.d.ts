import { isSet } from "./index";
export = isSet;
