import { cloneWith } from "./index";
export = cloneWith;
