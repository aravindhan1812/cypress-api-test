import { range } from "./index";
export = range;
