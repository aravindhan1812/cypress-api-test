import { stubTrue } from "./index";
export = stubTrue;
