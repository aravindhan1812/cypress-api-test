import { sortedIndexOf } from "./index";
export = sortedIndexOf;
