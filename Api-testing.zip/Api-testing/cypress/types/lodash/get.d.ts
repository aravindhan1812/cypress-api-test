import { get } from "./index";
export = get;
