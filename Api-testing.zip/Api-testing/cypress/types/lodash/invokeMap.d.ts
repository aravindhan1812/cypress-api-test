import { invokeMap } from "./index";
export = invokeMap;
