import { minBy } from "./index";
export = minBy;
