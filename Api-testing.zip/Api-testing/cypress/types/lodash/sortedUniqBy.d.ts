import { sortedUniqBy } from "./index";
export = sortedUniqBy;
