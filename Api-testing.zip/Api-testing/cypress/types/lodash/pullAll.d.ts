import { pullAll } from "./index";
export = pullAll;
