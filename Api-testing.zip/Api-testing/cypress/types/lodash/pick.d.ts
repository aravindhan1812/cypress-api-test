import { pick } from "./index";
export = pick;
