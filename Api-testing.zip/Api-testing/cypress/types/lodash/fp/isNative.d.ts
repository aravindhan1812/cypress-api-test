import { isNative } from "../fp";
export = isNative;
