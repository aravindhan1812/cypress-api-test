import { escapeRegExp } from "../fp";
export = escapeRegExp;
