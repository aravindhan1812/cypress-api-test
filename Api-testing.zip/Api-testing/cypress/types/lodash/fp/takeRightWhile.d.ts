import { takeRightWhile } from "../fp";
export = takeRightWhile;
