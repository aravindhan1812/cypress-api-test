import { assignInAllWith } from "../fp";
export = assignInAllWith;
