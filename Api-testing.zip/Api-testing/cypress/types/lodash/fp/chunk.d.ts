import { chunk } from "../fp";
export = chunk;
