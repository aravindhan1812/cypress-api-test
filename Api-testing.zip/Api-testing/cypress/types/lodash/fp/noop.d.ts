import { noop } from "../fp";
export = noop;
