import { sumBy } from "../fp";
export = sumBy;
