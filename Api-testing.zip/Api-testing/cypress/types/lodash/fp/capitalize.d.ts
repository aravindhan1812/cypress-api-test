import { capitalize } from "../fp";
export = capitalize;
