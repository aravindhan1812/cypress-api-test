import { T } from "../fp";
export = T;
