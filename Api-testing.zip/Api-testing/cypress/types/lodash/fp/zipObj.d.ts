import { zipObj } from "../fp";
export = zipObj;
