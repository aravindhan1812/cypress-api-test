import { noConflict } from "../fp";
export = noConflict;
