import { every } from "../fp";
export = every;
