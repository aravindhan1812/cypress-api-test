import { padCharsStart } from "../fp";
export = padCharsStart;
