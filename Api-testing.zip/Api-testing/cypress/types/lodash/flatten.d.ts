import { flatten } from "./index";
export = flatten;
