import { sortedIndexBy } from "./index";
export = sortedIndexBy;
