import { words } from "./index";
export = words;
