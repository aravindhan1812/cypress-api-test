import { isNull } from "./index";
export = isNull;
