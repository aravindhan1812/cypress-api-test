import { without } from "./index";
export = without;
