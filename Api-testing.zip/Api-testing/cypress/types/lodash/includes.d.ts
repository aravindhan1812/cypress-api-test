import { includes } from "./index";
export = includes;
