import { takeWhile } from "./index";
export = takeWhile;
