import { uniq } from "./index";
export = uniq;
