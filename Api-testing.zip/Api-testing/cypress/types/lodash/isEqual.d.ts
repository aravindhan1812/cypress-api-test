import { isEqual } from "./index";
export = isEqual;
